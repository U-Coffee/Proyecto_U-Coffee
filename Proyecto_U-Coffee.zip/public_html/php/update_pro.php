<?php

include_once("connect.php");

header("Access-Control-Allow-Origin: *");

if($_SERVER['REQUEST_METHOD'] !== 'POST'){
    echo json_encode(array('status'=>false));
    exit;
}

$postdata = file_get_contents("php://input");

$datos = json_decode($postdata,true);
$columna = $datos["columna"];
$dato = $datos["dato"];
$id = $datos["id"];

//cambiar el query por update

$query = "UPDATE product SET $columna = '$dato' WHERE codigo = '$id'";

echo mysqli_query($connect,$query);

?>  