<?php

include_once("connect.php");

header("Access-Control-Allow-Origin: *");

if($_SERVER['REQUEST_METHOD'] !== 'POST'){
    echo json_encode(array('status'=>false));
    exit;
}

$postdata = file_get_contents("php://input");

$datos = json_decode($postdata,true);
$nombre = $datos["nombre"];
$valor = $datos["valor"];
$img = $datos["img"];

$query = "INSERT INTO product (nombre,valor,img) value ('$nombre','$valor','$img')";

echo mysqli_query($connect,$query);

?>