<?php

include_once("connect.php");

header("Access-Control-Allow-Origin: *");

if($_SERVER['REQUEST_METHOD'] !== 'POST'){
    echo json_encode(array('status'=>false));
    exit;
}

$postdata = file_get_contents("php://input");

$datos = json_decode($postdata,true);
$ndoc = $datos["ndoc"];
$total = $datos["total"];
$desc = $datos["desc"];

$query = "INSERT INTO factura (idUser, descripcion,total) VALUE ('$ndoc','$desc','$total')";

echo mysqli_query($connect,$query);

?>