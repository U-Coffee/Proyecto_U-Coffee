<?php

include_once("connect.php");

header("Access-Control-Allow-Origin: *");

if($_SERVER['REQUEST_METHOD'] !== 'POST'){
    echo json_encode(array('status'=>false));
    exit;
}

$postdata = file_get_contents("php://input");

$datos = json_decode($postdata,true);
$dato_1 = $datos["user"];
$dato_2 = $datos["enviado"];

getLog($dato_1,$dato_2);

function getLog($dato1,$dato2){
    $query = "SELECT * FROM `factura`
    WHERE idUser = '$dato1' and enviado = '$dato2' ORDER BY idFactura DESC LIMIT 5";
    execQuery($query);
}

function imprimir($resultado){
    echo json_encode($resultado);
}

function execQuery($query){
    include "connect.php";
    $consulta = $connect->query($query);
    $res = array();
    if($consulta){
        while($resultado=mysqli_fetch_assoc($consulta)){
            $res[]=$resultado;
        }
        imprimir($res);
    }else{
        imprimir(mysqli_error($connect));
    }

}

?>