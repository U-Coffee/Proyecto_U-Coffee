<?php

include_once("connect.php");

header("Access-Control-Allow-Origin: *");

if($_SERVER['REQUEST_METHOD'] !== 'POST'){
    echo json_encode(array('status'=>false));
    exit;
}

$postdata = file_get_contents("php://input");

$datos = json_decode($postdata,true);
$correo = $datos["correo"];
$contra = $datos["contra"];

getLog($correo,$contra);

function getLog($dato,$dato1){
    $query = "SELECT ndoc FROM user WHERE ndoc = '$dato' AND contra = '$dato1'";
    execQuery($query);
}

function imprimir($resultado){
    echo json_encode($resultado);
}

function execQuery($query){
    include "connect.php";
    $consulta = $connect->query($query);
    $row = mysqli_fetch_array($consulta,MYSQLI_ASSOC);

    $count= mysqli_num_rows($consulta);

    imprimir($count);
}

?>