<?php

include_once("connect.php");

header("Access-Control-Allow-Origin: *");

if($_SERVER['REQUEST_METHOD'] !== 'POST'){
    echo json_encode(array('status'=>false));
    exit;
}

$postdata = file_get_contents("php://input");

$datos = json_decode($postdata,true);
$user = $datos["user"];
$name = $datos["name"];
$pass = $datos["pass"];

$query = "INSERT INTO coffee_user (user,pass,name) value ('$user','$pass','$name')";

echo mysqli_query($connect,$query);

?>