<?php

include_once("connect.php");

header("Access-Control-Allow-Origin: *");

if($_SERVER['REQUEST_METHOD'] !== 'POST'){
    echo json_encode(array('status'=>false));
    exit;
}

$postdata = file_get_contents("php://input");

$datos = json_decode($postdata,true);
$id = $datos["id"];
$table = $datos["table"];
$columna = $datos ["columna"];

//cambiar el query por update

$query = "DELETE FROM $table WHERE $columna = '$id'";

echo mysqli_query($connect,$query);

?>