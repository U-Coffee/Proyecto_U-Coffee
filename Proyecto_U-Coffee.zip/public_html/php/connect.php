<?php

$host = "localhost";
$user = "id15326104_u_coffee_web";
$password = "*JqDEJ~TV6*YHsd+";
$db = "id15326104_u_coffee";

$connect =mysqli_connect($host,$user,$password,$db) or die("problemas de conexión");

?>