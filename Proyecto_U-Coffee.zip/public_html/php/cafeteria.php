<?php

include_once("connect.php");

header("Access-Control-Allow-Origin: *");

if($_SERVER['REQUEST_METHOD'] !== 'POST'){
    echo json_encode(array('status'=>false));
    exit;
}

$postdata = file_get_contents("php://input");

$datos = json_decode($postdata,true);
$dato1_ = $datos["table"];
$dato2_ = $datos["pedido"];


getLog($dato1_,$dato2_);

function getLog($dato1,$dato2){
    $query = "SELECT factura.idFactura, user.nombre, user.apellido, factura.descripcion ,factura.total 
    FROM $dato1 inner JOIN user ON factura.idUser = user.ndoc AND factura.enviado = '$dato2' ORDER BY factura.idFactura asc 
    ";
    execQuery($query);
}

function imprimir($resultado){
    echo json_encode($resultado);
}

function execQuery($query){
    include "connect.php";
    $consulta = $connect->query($query);
    $res = array();
    if($consulta){
        while($resultado=mysqli_fetch_assoc($consulta)){
            $res[]=$resultado;
        }
        imprimir($res);
    }else{
        imprimir(mysqli_error($connect));
    }

}

?>