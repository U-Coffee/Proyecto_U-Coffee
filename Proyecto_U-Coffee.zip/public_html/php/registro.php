<?php

include_once("connect.php");

header("Access-Control-Allow-Origin: *");

if($_SERVER['REQUEST_METHOD'] !== 'POST'){
    echo json_encode(array('status'=>false));
    exit;
}

$postdata = file_get_contents("php://input");

$datos = json_decode($postdata,true);
$ndoc = $datos["ndoc"];
$nombre = $datos["nombre"];
$apellido = $datos["apellido"];
$correo = $datos["correo"];
$contra = $datos["contra"];

$query = "INSERT INTO user value ('$ndoc','$nombre','$apellido','$correo','$contra')";

echo mysqli_query($connect,$query);

?>