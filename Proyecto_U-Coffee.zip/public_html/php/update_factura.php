<?php

include_once("connect.php");

header("Access-Control-Allow-Origin: *");

if($_SERVER['REQUEST_METHOD'] !== 'POST'){
    echo json_encode(array('status'=>false));
    exit;
}

$postdata = file_get_contents("php://input");

$datos = json_decode($postdata,true);
$pedido = $datos["pedido"];
$dato = $datos["dato"];

//cambiar el query por update

$query = "UPDATE factura SET enviado = '$dato' WHERE idFactura = '$pedido'";

echo mysqli_query($connect,$query);

?>